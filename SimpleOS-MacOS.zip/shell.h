#include "struct.h"
#include "cpu.c"
#include "ReadyQueue.h"

int parse(char ui[], storage_t *memory, aCPU *core, readyQueue *rQ);
