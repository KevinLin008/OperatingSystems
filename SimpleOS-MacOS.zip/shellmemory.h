#include "struct.h"

void add(char variable[], char value[], storage_t *memory);
int check(char variable[], storage_t *memory);
int display(char variable[], storage_t *memory);
void replace(char variable[], char replacement[], storage_t *memory);
