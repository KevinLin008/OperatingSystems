#ifndef ram_h
#define ram_h

extern FILE *ram[10];
void addToRAM(FILE *p);
void freeRam(FILE *file);


#endif /* ram_h */
