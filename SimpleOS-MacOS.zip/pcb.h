#include "ReadyQueue.h"

aPCB* makePCB(FILE *p);
