#ifndef INTERPRETERH
#define INTERPRETERH
// public functions

int interpreter(char arg0[], char arg1[], char arg2[], char arg3[]);
#endif
