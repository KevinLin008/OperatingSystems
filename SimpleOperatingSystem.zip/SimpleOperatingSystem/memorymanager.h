#ifndef MEMMANAGERH
#define MEMMANAGERH
#include <stdio.h>
int launcher(FILE *p);
FILE *findPage(int pageNumber, FILE *p);
int findFrame(FILE *p);
#endif
