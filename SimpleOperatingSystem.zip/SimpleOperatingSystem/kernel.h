#ifndef KERNELH
#define KERNELH
#include "pcb.h"
int myinit(PCB *pcb);
void scheduler();
#endif
